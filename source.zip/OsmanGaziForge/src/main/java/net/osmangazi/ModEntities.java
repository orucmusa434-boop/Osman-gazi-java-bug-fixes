package net.osmangazi;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, OsmanGaziMod.MODID);
    private static final Map<String, RegistryObject<EntityType<OsmanUnit>>> TYPES = new HashMap<>();

    static {
        for (UnitDef def : UnitDef.ALL) {
            TYPES.put(def.id(), ENTITIES.register(def.id(), () ->
                EntityType.Builder.<OsmanUnit>of((type, level) -> new OsmanUnit(type, level, def), MobCategory.CREATURE)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build(def.id())));
        }
    }

    public static EntityType<OsmanUnit> type(String id) { return TYPES.get(id).get(); }
    public static RegistryObject<EntityType<OsmanUnit>> object(String id) { return TYPES.get(id); }

    public static void attributes(EntityAttributeCreationEvent e) {
        for (UnitDef def : UnitDef.ALL) e.put(type(def.id()), OsmanUnit.createAttributes(def).build());
    }

    public static void spawnPlacements(SpawnPlacementRegisterEvent e) {
        for (UnitDef def : UnitDef.ALL)
            e.register(type(def.id()), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Mob::checkMobSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
    }
}
