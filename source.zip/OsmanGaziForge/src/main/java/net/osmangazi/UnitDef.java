package net.osmangazi;

import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.resources.ResourceLocation;

public record UnitDef(String id, Faction faction, Role role, double health, double attack, double speed, String[] tameItems,
                      float tameChance, String weapon, boolean shield, float scale, int egg1, int egg2, int spawnWeight) {
    public enum Faction { ALP, MONGOL, BARBAR }
    public enum Role { MELEE, ARCHER, HAMMER, SHIELD, MINER, COMMANDER, KING }

    public boolean isTameItem(ItemStack s) {
        if (s.isEmpty()) return false;
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (k == null) return false;
        for (String t : tameItems) if (t.equals(k.toString())) return true;
        return false;
    }

    public static final List<UnitDef> ALL = List.of(
        new UnitDef("alp", Faction.ALP, Role.MELEE, 40D, 1.0D, 0.3D, new String[]{"minecraft:diamond"}, 0.5F, "osmangazi:alp_kilici", false, 1.0F, 0xA02828, 0xE6C850, 3),
        new UnitDef("alp_okcu", Faction.ALP, Role.ARCHER, 30D, 3.0D, 0.27D, new String[]{"minecraft:gold_ingot"}, 0.5F, "osmangazi:alp_yayi", false, 1.0F, 0x566840, 0xA02828, 3),
        new UnitDef("alp_cekicli", Faction.ALP, Role.HAMMER, 60D, 3D, 0.27D, new String[]{"minecraft:oak_door"}, 0.5F, "osmangazi:alp_cekici", false, 1.0F, 0xA02828, 0x969CA8, 1),
        new UnitDef("alp_kalkanli", Faction.ALP, Role.SHIELD, 70D, 1.0D, 0.26D, new String[]{"minecraft:coal"}, 0.5F, "osmangazi:alp_kilici", true, 1.0F, 0xA02828, 0x969CA8, 1),
        new UnitDef("alp_kazmaci", Faction.ALP, Role.MINER, 40D, 1.0D, 0.3D, new String[]{"osmangazi:alp_kazmasi"}, 0.5F, "osmangazi:alp_kazmasi", false, 1.0F, 0xA02828, 0xF0BE28, 1),
        new UnitDef("konur_alp", Faction.ALP, Role.COMMANDER, 160D, 4D, 0.32D, new String[]{"minecraft:golden_apple", "osmangazi:alp_kazmasi"}, 0.15F, "osmangazi:alp_mizragi", false, 1.12F, 0xA02828, 0xFFD23C, 0),
        new UnitDef("osman_gazi", Faction.ALP, Role.KING, 150D, 6D, 0.32D, new String[]{"minecraft:diamond_block"}, 0.5F, "osmangazi:osman_kilici", false, 1.2F, 0x1E7341, 0xEBC846, 0),
        new UnitDef("mongol_asker", Faction.MONGOL, Role.MELEE, 32D, 1.0D, 0.28D, new String[]{"minecraft:emerald"}, 0.5F, "osmangazi:mongol_kilici", false, 1.0F, 0x2D3C64, 0xAA2828, 3),
        new UnitDef("mongol_okcu", Faction.MONGOL, Role.ARCHER, 26D, 3.0D, 0.27D, new String[]{"minecraft:gold_ingot"}, 0.5F, "osmangazi:mongol_yayi", false, 1.0F, 0x3C5C62, 0xAA2828, 3),
        new UnitDef("mongol_cekicli", Faction.MONGOL, Role.HAMMER, 60D, 3D, 0.27D, new String[]{"minecraft:birch_door"}, 0.5F, "osmangazi:mongol_cekici", false, 1.0F, 0x2D3C64, 0x464852, 1),
        new UnitDef("mongol_kalkanli", Faction.MONGOL, Role.SHIELD, 70D, 1.0D, 0.26D, new String[]{"minecraft:lapis_lazuli"}, 0.5F, "osmangazi:mongol_kilici", true, 1.0F, 0x2D3C64, 0x34261A, 1),
        new UnitDef("mongol_kazmaci", Faction.MONGOL, Role.MINER, 40D, 1.0D, 0.28D, new String[]{"osmangazi:mongol_kazmasi"}, 0.5F, "osmangazi:mongol_kazmasi", false, 1.0F, 0x2D3C64, 0xE07024, 1),
        new UnitDef("konur_mongol", Faction.MONGOL, Role.COMMANDER, 160D, 5D, 0.32D, new String[]{"minecraft:golden_apple", "osmangazi:mongol_kazmasi"}, 0.15F, "osmangazi:mongol_mizragi", false, 1.12F, 0x2D3C64, 0xFF9A28, 0),
        new UnitDef("nayman", Faction.MONGOL, Role.KING, 300D, 4D, 0.3D, new String[]{"minecraft:emerald_block"}, 0.4F, "osmangazi:nayman_kilici", false, 1.2F, 0x2D193C, 0xD7AA28, 0),
        new UnitDef("barbar", Faction.BARBAR, Role.MELEE, 32D, 1.0D, 0.28D, new String[]{"minecraft:iron_ingot"}, 0.5F, "osmangazi:barbar_baltasi", false, 1.0F, 0x46542E, 0xB8A078, 3),
        new UnitDef("barbar_okcu", Faction.BARBAR, Role.ARCHER, 26D, 3.0D, 0.27D, new String[]{"minecraft:copper_ingot"}, 0.5F, "osmangazi:barbar_yayi", false, 1.0F, 0x5C4A30, 0x46542E, 3),
        new UnitDef("barbar_cekicli", Faction.BARBAR, Role.HAMMER, 60D, 3D, 0.27D, new String[]{"minecraft:acacia_door"}, 0.5F, "osmangazi:barbar_cekici", false, 1.0F, 0x46542E, 0x7A7A80, 1),
        new UnitDef("barbar_kalkanli", Faction.BARBAR, Role.SHIELD, 70D, 1.0D, 0.26D, new String[]{"minecraft:redstone"}, 0.5F, "osmangazi:barbar_baltasi", true, 1.0F, 0x46542E, 0x8A5A34, 1),
        new UnitDef("barbar_kazmaci", Faction.BARBAR, Role.MINER, 40D, 1.0D, 0.28D, new String[]{"osmangazi:barbar_kazmasi"}, 0.5F, "osmangazi:barbar_kazmasi", false, 1.0F, 0x46542E, 0xB09660, 1),
        new UnitDef("konur_barbar", Faction.BARBAR, Role.COMMANDER, 160D, 4D, 0.32D, new String[]{"minecraft:golden_apple", "osmangazi:barbar_kazmasi"}, 0.15F, "osmangazi:barbar_mizragi", false, 1.12F, 0x46542E, 0xD23C3C, 0),
        new UnitDef("alpago", Faction.ALP, Role.KING, 300D, 4D, 0.3D, new String[]{"minecraft:iron_block"}, 0.4F, "osmangazi:alpago_baltasi", false, 1.2F, 0x23231F, 0xD7AA28, 0));
}
