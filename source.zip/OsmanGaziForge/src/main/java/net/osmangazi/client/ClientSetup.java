package net.osmangazi.client;

import net.osmangazi.ModEntities;
import net.osmangazi.OsmanGaziMod;
import net.osmangazi.UnitDef;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = OsmanGaziMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        for (UnitDef def : UnitDef.ALL)
            e.registerEntityRenderer(ModEntities.type(def.id()), ctx -> new OsmanRenderer(ctx, def));
    }
}
